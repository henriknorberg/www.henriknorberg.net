//***********************************************
//*
//*              MENU View
//*
//***********************************************

$(function() { 

    

    var s = {}; // s == static vars
    var p = {}; // p == properties

// static interface:

// public properties:
    p._menu = null;
    p._myStateData = null;
    p._myDemoData = null;
    p._underline = null;
    p._stateColor = null;
    p._tempMenuItem = null;
    p._setRegElement = null;

    p._activeMenu =null;

    p.events = {
        'click .main-menu li a': '_handleClick',
        'mouseenter .main-menu li a':'_handleMouseEnter',
        'mouseleave .main-menu li a':'_handleMouseLeave',
        'focusin .main-menu li a':'_handleMouseEnter',
        'focusout .main-menu li a':'_handleMouseLeave'
    };

//  public methods:
    p.initialize = function(params) {        
        this.model.bind('change:menuState', this._updateState, this);


        this._menu = this.$('.main-menu'); //not SET!
        this._menu.append('<li class="main-menu-underline nav-item"></li>');

        this._activeMenu =".home";
        this._underline = $('.main-menu-underline');
        
        console.log("MainMenuView INIT");
    }

//  protected methods:
    p._updateState = function (model, value, options) {
        

        var titleTag = appData[value].banner.description;
        this.$('.main-menu a').attr('title', titleTag);
        
        this._myStateData = appData[value].stateData;
        this._tempMenuItem = this.$('.' + appData[value].stateData.classID);
        this._stateColor = this._myStateData.color;

        console.log("updateState: "+this);
        
        this._updateUnderline();
    }
    p._updateUnderline = function () {

        if (this._setRegElement) this._setRegElement.removeClass("activeMenu");
        this._setRegElement = this.model.get('menuState') ? this._tempMenuItem : this._activeMenu;
        this._setRegElement.addClass("activeMenu");
        //var newWidth = $(this._setRegElement).find('.text-product').width();
        var newWidth = $(this._setRegElement).width();
        console.log("_updateUnderline: width ==   "+ newWidth);
       
        var newXPos = Math.floor(this._setRegElement.position().left);
       
        this._underline.css({"left" : newXPos, "background-color" : this._stateColor});
        this._underline.width(newWidth);
    }

    //  HOVER STATES
    p._handleMouseEnter = function (event) {
        console.log("Mouse Over Menu");
        this.model.set({
            //menuState: $(event.currentTarget).attr("data-state");
        });
    }
    p._handleMouseLeave = function (event) {
        console.log("Mouse Out Menu");
        this.model.set({
            menuState: this.model.get('state')
        });
    }


    p._handleClick = function (event){
        var isDisabled = $(event.currentTarget).hasClass("disabled")
        if(isDisabled){
            event.preventDefault();
        }
    }
    

//  create object
    window.MainMenuView = Backbone.View.extend(p, s);

});