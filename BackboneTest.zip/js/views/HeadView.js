//***********************************************
//*
//*          	HEAD View
//*
//***********************************************

$(function() {



    var s = {}; // s == static vars
    var p = {}; // p == properties

// static interface:

// public properties:
    p._myData = undefined;
    p._favicon = null;
    p._description = null;

//  public methods:
    p.initialize = function(params) {
        this.model.bind('change:state', this._updateState, this);
        this._favicon = $('#favicon');
        this._description = $('meta[name=description]');
        console.log("HeadView INIT") 
    };

//  protected methods:
    p._updateState = function (model, value, options) {
        console.log("HEADView _updateState: "+appData[value]);

        this._myData = appData[value];
        this._favicon.attr('href', this._myData.headData.favicon);
        
        if(this.model.get('showDemoView')){
            this._replaceWithDemoData();
        } else {
            this._replaceWithStateData();
        }
    };
    p._replaceWithStateData = function () {
        document.title = this._myData.headData.titleTag;
        this._description.attr('content', this._myData.headData.description);
    };
	window.HeadView = Backbone.View.extend(p, s);
});