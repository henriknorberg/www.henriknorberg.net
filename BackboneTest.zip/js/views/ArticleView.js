//***********************************************
//*
//*          	HEAD View
//*
//***********************************************

$(function() {



    var s = {}; // s == static vars
    var p = {}; // p == properties

// static interface:

// public properties:
    p._data = undefined;

    p._pageElements = null;

//  public methods:
    p.initialize = function(params) {
        this.model.bind('change:state', this._updateState, this);
    
        
        this._preHeadline = this.$('.pre-headline');
        this._h1 = this.$('h1');
        this._h2 = this.$('h2');
        this._article = this.$('section p');

        this._pageElements = [this._preHeadline,this._h1,this._h2,this._article];
         console.log("Article VIEW INIT")  
    };

//  protected methods:
    p._updateState = function (model, value, options) {
        console.log("ArticleView _updateState: "+appData[value]);

        this._data = appData[value];
        this._stateColor = this._data.stateData.color;

       // /* ANIMATE OUT
         p._transAllOut(this._pageElements);
        var that = this;
        setTimeout(function(){
            that._replaceWithStateData();
        }, AppModel.STEP_SPEED * Math.floor(this._pageElements.length/2));

        //*/

        //this._replaceWithStateData();
    };

    p._replaceWithStateData = function () {
        console.log(" Title  "+this._data.story.title);
        
        //Henrik todo: make clean up functions in case new content fails

        this._preHeadline.html(this._data.story.preHeadline);
        this._h1.html( this._data.story.title).css({"color":this._stateColor});
        this._h2.html( this._data.story.subTitle);
        this._article.html( this._data.story.story);

        p._initAnimState(this._pageElements);

        p._transAllIn(this._pageElements);


    };

    p._initAnimState = function (elems){
         elems.forEach(function(el){
            el.addClass('initState').removeClass('in').removeClass('out');
         });
    };

    p._transAllIn = function (elems){
        elems.forEach(function(el,indx){
                setTimeout(function(){
                      p._transIn(el);
                    }, AppModel.STEP_SPEED * (indx));
        });
    };

    p._transAllOut = function (elems){
        if(!elems) return
        elems.forEach(function(el,indx){
                setTimeout(function(){
                      p._transOut(el);
                    }, AppModel.STEP_SPEED * indx);
        });
    };

    p._transIn = function (el) {
       el.addClass('in').removeClass('out');
    };

    p._transOut = function (el) {
      el.addClass('out').removeClass('in');
    };

	window.ArticleView = Backbone.View.extend(p, s);
}); 