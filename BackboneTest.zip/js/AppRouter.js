//***********************************************
//*
//*          	APPLICATION Router
//*
//***************************************** 

$(function () {

    var s = {};
    var p = {};


//	static properties:


//	public properties:
    p.model = null;
    p._stateQuery = null;
    p._data = null;
    p.routes = {
        "" : "_navigateToHome",
        ":query/:product" : "_navigateToState",
        "*undefined": "_navigate404"
    };



//	public methods:
    p.initialize = function (params) {
        this.model = params.model;
    };

//  protected methods:
    p._navigateToHome = function() {
        this._navigate('home', true);
    };

    p._navigateToState = function(query, product) {
        this._data = appData[product];
         console.log('AppRoute: Navigate to State ', product);

        if(this._data){
            
            // state setup
            this.model.set({
                stateClass: this._data.stateData.classID,
                state: product,
                menuState: product,
                btnBarState: product,
                showDemoView: false
            });

            var myQuery = '#!/'+product;
            this._navigate(myQuery);
        } else {
            this._navigate404();
        }

        // navigate
    };

    p._navigate = function (query) {
        // console.log('Navigating to ', query);
        this.navigate(""+query, {trigger:true, replace:true, pushstate:true});        
    }
    //  Error handling
    p._navigate404 = function () {
         console.log('404page');
        //window.location = '/404.html';
    }

//	create object
	window.AppRouter = Backbone.Router.extend(p, s);
    //window.AppRouter.history.start({pushState:true});
});