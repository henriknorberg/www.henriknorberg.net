//***********************************************
//*
//*          	APPLICATION Model
//*
//***********************************************

$(function () {

    var s = {};
    var p = {};


//	static properties:
    s.debugMode = true;
    s.TRANS_SHORT = 250;
    s.TRANS_LONG = 500;
    s.STEP_SPEED = 250;

//	public properties:
    p.defaults = {
        scrollY:            null,
        home:               "Home",
        // States
        state:              null,
        stateClass:         null,
        btnBarState:        null,
        menuState:          null,
        menuStateColor:     null,
        // Feature Area
        allowSwapFeature:   null,
        // Demos
        demoIndex:          null,
        // Modals
        showModal:          false,
	    showModalOnLoad:    false,
        showModalDemo:      false,
        showModalDownload:  false,
 		// Data
        gitDataURL:         null,
        gitData:            null,
        stateData:          null,
        headData:           null,
        newsData:           null,
 		featureProductData: null,
        storyData:          null,
        docs:               null,
        tutorials:          null,
        updates:            null
    };

//	public methods:
console.log("APP MODEL INIT") 

//	create object
	window.AppModel = Backbone.Model.extend(p, s);

});